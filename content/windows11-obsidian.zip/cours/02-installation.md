# 02. Installation, mise à niveau et comptes

> [!abstract] Parcours TSSR
> Toutes les parties non marquées (bonus) sont à réaliser ; les exercices complémentaires sont facultatifs.
> Les sections marquées (bonus) sont facultatives.

> [!NOTE] Objectif
> Connaître les prérequis matériels de Windows 11, choisir l'édition, réaliser une installation propre, mettre à niveau un poste existant, et comprendre les trois types de comptes (local, Microsoft, professionnel).
>
> **Outils :** ISO Windows 11, Gestionnaire Hyper-V, `setup.exe`
> **Commandes à connaître :** `Shift+F10`, `setup.exe /auto upgrade`, `dsregcmd /status`, `Get-LocalUser`

> [!INFO] Fil rouge — Fournil
> On installe `PC01` (Windows 11 Pro 26H2) dans la VM créée au chapitre 01.

---

## Configuration requise

Windows 11 impose des **exigences matérielles strictes** par rapport à Windows 10. Ces prérequis visent à garantir un socle de sécurité minimal (TPM, Secure Boot, VBS).

| Composant | Minimum requis |
|-----------|---------------|
| Processeur | 1 GHz, 2 cœurs minimum, 64 bits, compatible |
| RAM | 4 Go |
| Stockage | 64 Go |
| Firmware | UEFI avec **Secure Boot** |
| TPM | **Version 2.0** |
| Carte graphique | DirectX 12 avec pilote WDDM 2.0 |
| Écran | 720p, 9 pouces minimum |
| Connexion | Compte Microsoft requis pour l'édition Home (contournable) |

### Pourquoi ces exigences ?

![Exigences de sécurité à l’installation — Windows 10 pouvait être installé en BIOS ou UEFI. Windows 11 exige UEFI et TPM et s’appuie sur Secure Boot en plus de la sécurité logicielle.](../assets/captures/w11-schema-02-securite-exigences.svg)

| Technologie | Rôle |
|-------------|------|
| **TPM 2.0** | Puce de sécurité qui stocke les clés de chiffrement (BitLocker), les certificats et les mesures d'intégrité du boot |
| **Secure Boot** | Vérifie que chaque composant chargé au démarrage (bootloader, drivers) est signé numériquement — empêche les rootkits |
| **VBS** | Virtualisation-Based Security — isole les processus critiques du noyau dans un environnement protégé par l'hyperviseur |

> [!TIP] En VM Hyper-V
> La Génération 2 fournit le TPM virtuel et le Secure Boot. C'est pour cela qu'on a activé le TPM dans le chapitre 1 avec `Enable-VMTPM`.

---

## Les éditions de Windows 11

| Édition | Public cible | Fonctionnalités clés |
|---------|-------------|---------------------|
| **Home** | Grand public | Windows Hello, Device Encryption, Snap Layouts, DirectStorage |
| **Pro** | Professionnels, PME | Home + **Hyper-V**, **BitLocker**, **Bureau à distance (hôte)**, **GPO locale**, jonction AD / Entra ID, Windows Update client policies, App Control for Business |
| **Enterprise** | Grandes entreprises (abonnement E3/E5) | Pro + Credential Guard activé par défaut, **Hotpatch**, Windows Autopatch, suppression d'applis préinstallées par GPO, 36 mois de support |
| **Education** | Écoles, universités | ≈ Enterprise avec licences éducation |

### Ce qui nous intéresse pour cette formation

| Fonctionnalité | Home | Pro | Enterprise |
|----------------|------|-----|------------|
| Hyper-V | ❌ | ✅ | ✅ |
| BitLocker | ❌ | ✅ | ✅ |
| Bureau à distance (hôte) | ❌ | ✅ | ✅ |
| Jonction domaine AD | ❌ | ✅ | ✅ |
| Group Policy (gpedit.msc) | ❌ | ✅ | ✅ |
| App Control for Business / AppLocker | ❌ | ✅ (testé au TP 09) | ✅ |
| Hotpatch (mises à jour sans redémarrage) | ❌ | ❌ | ✅ |
| RAM max | 128 Go | 2 To | 6 To |

> [!NOTE] AppLocker sur Pro
> Longtemps réservé à Enterprise, AppLocker s'applique aussi sur Pro depuis Windows 10 2004 — la documentation Microsoft reste ambiguë, c'est pourquoi le TP 09 le vérifie en vrai sur `PC01`. Son successeur, **App Control for Business** (ex-WDAC), est officiellement supporté sur Pro.

> [!WARNING] Windows 11 Home est insuffisant pour un environnement professionnel
> Pas de Hyper-V, pas de BitLocker, pas de jonction au domaine, pas de GPO. Pour cette formation et en entreprise, il faut au minimum **Windows 11 Pro**.

---

## Obtenir l'ISO Windows 11

Trois méthodes officielles depuis le site Microsoft :

| Méthode | Usage |
|---------|-------|
| **Assistant d'installation** | Mise à niveau d'un Windows 10/11 existant |
| **Outil de création de support** | Créer une clé USB bootable |
| **Téléchargement ISO** | Télécharger le fichier ISO directement (pour VM ou gravure) |

Pour le lab, on utilise le **téléchargement ISO direct** qu'on monte ensuite dans Hyper-V.

---

## Installation propre

### Lancer l'installation

1. Ouvrir la console de la VM (**Connecter…**) **avant** de la démarrer
2. Démarrer la VM et appuyer sur une touche dès que le message *Press any key to boot from CD or DVD* apparaît (quelques secondes seulement)

![w11-02-press-any-key](../assets/captures/w11-02-press-any-key.png)

### Écrans de l'installation (installeur 24H2 et suivants)

Depuis la 24H2, l'installeur a été refait. Les anciens écrans « Installer maintenant » et « Personnalisée (avancé) » n'existent plus, sauf en cliquant sur le lien *Version précédente de la configuration*. Relevé sur l'ISO 26300.9457 du lab :

#### 1. Langue et format

*Langage à installer* et *Format de l'heure et de la devise* : **Français (France)** → **Suivant**.

![w11-02-setup-langue](../assets/captures/w11-02-setup-langue.png)

#### 2. Clavier

**Français (Traditionnel, AZERTY)**, c'est l'AZERTY habituel → **Suivant**.

#### 3. Option d'installation

Laisser **Installer Windows 11**, puis **cocher** *J'accepte que tout soit supprimé, y compris les fichiers, les applications et les paramètres*. **Tant que la case n'est pas cochée, le bouton Suivant reste grisé.**

![w11-02-setup-option-installation](../assets/captures/w11-02-setup-option-installation.png)

#### 4. Clé de produit

- En entreprise : entrer la clé de licence volume
- En lab : cliquer sur le lien **Je n'ai pas de clé de produit (Product Key)**, en bas à gauche

![w11-02-setup-cle-produit](../assets/captures/w11-02-setup-cle-produit.png)

> [!TIP] Sans clé de produit
> Windows 11 s'installe et fonctionne normalement sans clé. Un filigrane « Activer Windows » apparaît et la page **Personnalisation** affiche *« Vous devez activer Windows pour pouvoir personnaliser votre PC »*. Sur le lab, les réglages utiles au TP 03 (menu Démarrer, barre des tâches) restent pourtant modifiables. Seuls le fond d'écran et les couleurs sont bloqués.

#### 5. Choix de l'image (édition)

> [!WARNING] L'édition présélectionnée est **Windows 11 Famille**
> Cliquer **Windows 11 Professionnel** avant **Suivant**. Un poste installé en Famille ne pourra **ni rejoindre le domaine (chapitre 10) ni recevoir de GPO** : il faudrait tout réinstaller.

![w11-02-setup-edition](../assets/captures/w11-02-setup-edition.png)

#### 6. Contrat de licence

**Accepter**.

#### 7. Emplacement d'installation

Sur un disque vierge (cas de notre VM), l'installeur affiche *Espace disque 0 non alloué* (64 Go).

![w11-02-setup-disque](../assets/captures/w11-02-setup-disque.png)

- Laisser **Espace non alloué** sélectionné → **Suivant**, sans rien créer
- Windows crée automatiquement les partitions nécessaires :

![Partitions du disque d’installation — Exemple de disque de 64 Go avec, dans l’ordre, les partitions EFI, MSR, Windows et Récupération.](../assets/captures/w11-schema-02-partitions-installation.svg)

Relevé réel sur `PC01` (26H2) :

```
PartitionNumber Type        MB DriveLetter
--------------- ----        -- -----------
              1 System     200
              2 Reserved    16
              3 Basic    64411           C
              4 Recovery   906
```

> [!NOTE] Pourquoi la récupération est-elle à la fin ?
> Les anciennes installations plaçaient WinRE **avant** C:. Quand une mise à jour de WinRE demandait plus de place, impossible d'agrandir la partition coincée devant le système. Placée **après** C:, elle peut être agrandie en réduisant C: (cas célèbre de la mise à jour KB5034441 en 2024).

> [!TIP] Partitions automatiques
> Il n'est pas nécessaire de créer manuellement les partitions. L'installeur gère tout seul la structure GPT/UEFI. Ne touche pas aux partitions système/EFI/récupération.

#### 8. Prêt pour l'installation

Le résumé doit indiquer **Installer Windows 11 Professionnel** et **Ne rien conserver** → **Installer**.

![w11-02-setup-pret](../assets/captures/w11-02-setup-pret.png)

L'installeur copie les fichiers, installe les fonctionnalités et les mises à jour. La VM redémarre plusieurs fois. **Ne pas appuyer sur une touche** lors des redémarrages (sinon on relance l'installeur). Sur le lab, il a fallu **environ 15 minutes** entre le clic sur *Installer* et le premier écran de l'OOBE.

---

## OOBE — Premier démarrage

Après l'installation, Windows lance l'**OOBE** (Out-Of-Box Experience) : l'assistant de configuration initiale.

### Étapes de l'OOBE

![Les étapes de l’OOBE — La première configuration va du choix de la région jusqu’au Bureau, en passant par le réseau et la création du compte.](../assets/captures/w11-schema-02-oobe.svg)

#### Région et clavier

- Pays : **France**
- Disposition clavier : **Français**
- Deuxième disposition : **Ignorer**

#### Nom du PC

Selon le chemin suivi, l'OOBE propose parfois de nommer l'appareil. **Sur le lab (sans Internet, compte local), cet écran n'apparaît pas** : le poste reçoit un nom aléatoire `DESKTOP-XXXXXXX`, qu'on renomme juste après l'OOBE.

**En graphique** : **Paramètres → Système → Informations système → Renommer ce PC** → `PC01` → **Suivant** → **Redémarrer maintenant**.

![w11-02-renommer-ce-pc](../assets/captures/w11-02-renommer-ce-pc.png)

**En PowerShell** (administrateur) :

```powershell
Rename-Computer -NewName PC01 -Restart
```

> [!TIP] Nommer le PC avant la jonction au domaine
> Le nom du PC est utilisé dans le réseau, le DNS et Active Directory. Il faut le fixer **avant** de joindre le domaine (chapitre 10) : un renommage après jonction est possible, mais il touche aussi l'objet ordinateur dans AD.

#### Connexion réseau et compte Microsoft

L'OOBE demande une connexion Internet et un **compte Microsoft**. En lab et en entreprise, on veut un **compte local** à la place.

---

## Les trois types de comptes

| Type | Exemple | Où vit le compte | Usage |
|------|---------|------------------|-------|
| **Local** | `PC01\admin` | Base SAM du poste | Lab, poste isolé, compte de secours |
| **Compte Microsoft** (MSA) | `prenom@outlook.fr` | Cloud Microsoft (grand public) | Particuliers : synchronisation, OneDrive perso, Store |
| **Compte professionnel** (Entra ID) | `prenom@fournil.fr` | **Microsoft Entra ID** (ex-Azure AD) | Entreprises M365 : Intune, Autopilot, OneDrive pro, SSO |
| **Compte de domaine** (AD DS) | `FOURNIL\stagiaire` | Active Directory sur site | Entreprises avec contrôleurs de domaine (chapitre 10) |

Un poste peut être, au choix ou en combinaison :

![Comptes et jonction du poste — Les comptes associés au groupe de travail, au domaine AD, à Entra ID et à la jonction hybride.](../assets/captures/w11-schema-02-comptes-jonction.svg)

```cmd
:: Voir le type de jonction d'un poste
dsregcmd /status
```

Sur `PC01` à ce stade : `AzureAdJoined : NO`, `DomainJoined : NO` (groupe de travail).

---

## Obtenir un compte local à l'installation

Sur Windows 11 Home **et Pro**, l'OOBE impose un compte Microsoft ou professionnel et une connexion Internet. Les contournements « historiques » ont été supprimés un par un :

| Méthode | Statut fin 2026 |
|---------|-----------------|
| `Shift+F10` → `OOBE\BYPASSNRO` | ⚠️ **Variable selon la build** : retiré de certaines builds Insider 26300, mais encore présent sur l'ISO publique 26300.9457 du lab (`C:\Windows\System32\oobe\BypassNRO.cmd`) |
| `Shift+F10` → `start ms-cxh:localonly` | ❌ Bloqué depuis les builds 26120/26220.6772 |
| Clé `HKLM\...\OOBE\BypassNRO = 1` + redémarrage | ⚠️ Ce que fait le script ci-dessus ; **non documenté**, peut disparaître à tout moment |
| E-mail bidon type `no@thankyou.com` | ❌ Ne fonctionne plus |

> [!WARNING] Ne pas bâtir une procédure sur un contournement
> Microsoft retire ces astuces au fil des builds : ce qui marche sur l'ISO de septembre peut échouer sur celle de décembre. En formation comme en production, on présente ces méthodes comme **culture**, et on s'appuie sur les méthodes pérennes ci-dessous.

Les méthodes **pérennes**, celles qu'un administrateur utilise :

### 1. Le fichier de réponse (méthode professionnelle)

Un `autounattend.xml` à la racine du support d'installation masque les écrans de compte en ligne et crée le compte local :

```xml
<OOBE>
  <HideOnlineAccountScreens>true</HideOnlineAccountScreens>
  <HideLocalAccountScreen>true</HideLocalAccountScreen>
</OOBE>
<UserAccounts>
  <LocalAccounts>
    <LocalAccount wcm:action="add">
      <Name>admin</Name><Group>Administrators</Group>
      <Password><Value>Fournil2026!</Value><PlainText>true</PlainText></Password>
    </LocalAccount>
  </LocalAccounts>
</UserAccounts>
```

C'est **la méthode supportée par Microsoft**, et celle qu'on construira proprement avec Windows SIM au chapitre 13. Le lab formateur a été installé ainsi, en zéro clic.

### 2. Ce qui se passe vraiment sans réseau (testé sur 26300.9457)

Débrancher le réseau **ne suffit plus**. Sur le lab, sans carte réseau connectée, l'OOBE bloque sur cet écran : bouton **Suivant grisé**, aucune autre issue que « Installer le pilote ».

![w11-02-oobe-reseau-obligatoire](../assets/captures/w11-02-oobe-reseau-obligatoire.png)

C'est exactement la situation de `PC01` dans le lab : `vSwitch-Rennes` n'a **pas encore de serveur DHCP** (il arrivera avec SRV01 au chapitre 10), la VM n'a donc ni adresse ni Internet pendant l'OOBE.

Procédure validée sur le lab (ISO 26300.9457) :

1. Sur l'écran *Il est temps de vous connecter à un réseau*, appuyer sur **`Shift + F10`** : une invite de commandes **administrateur** s'ouvre (cliquer dedans si le curseur ne clignote pas).
2. Taper `OOBE\BYPASSNRO` puis **Entrée**. Le clavier est déjà en AZERTY : le `\` s'obtient avec **`AltGr + 8`**. Ce script écrit la clé `BypassNRO=1`, puis redémarre la VM.

![w11-02-oobe-shift-f10-bypassnro](../assets/captures/w11-02-oobe-shift-f10-bypassnro.png)

3. Après le redémarrage, l'OOBE **reprend au début** : refaire *Pays* et *Clavier*.
4. L'écran réseau affiche maintenant le lien **« Je n'ai pas Internet »** → cliquer dessus.

![w11-02-oobe-bypassnro-pas-internet](../assets/captures/w11-02-oobe-bypassnro-pas-internet.png)

5. *Qui utilisera cet appareil ?* → `admin` → mot de passe `Fournil2026!` (deux fois).

![w11-02-oobe-compte-local](../assets/captures/w11-02-oobe-compte-local.png)

6. **Trois questions de sécurité**, obligatoires pour un compte local : choisir une question dans la liste, saisir la réponse, recommencer trois fois.

![w11-02-oobe-questions-securite](../assets/captures/w11-02-oobe-questions-securite.png)

7. Les écrans de confidentialité défilent ensuite **un par un** (emplacement, Localiser mon appareil, diagnostic, saisie, expériences personnalisées, publicité…) : choisir **Non** à chaque fois, puis **Accepter**.

> [!WARNING] Écran « Envoyer des données de diagnostic »
> Sur cet écran, la première carte (**Inclure facultatif**) est très haute : l'option **Obligatoire uniquement** est **en dessous**, il faut faire défiler la liste pour la voir. Un clic trop rapide active les données facultatives. Ce n'est pas grave : on corrige ensuite dans **Paramètres → Confidentialité et sécurité → Diagnostics et commentaires**.

![w11-02-oobe-diagnostic-piege](../assets/captures/w11-02-oobe-diagnostic-piege.png)

Ça fonctionne **aujourd'hui sur cette build** — rien ne garantit que ce sera le cas sur la prochaine ISO. Si `BYPASSNRO` a disparu, la solution de repli est un fichier de réponse (méthode 1) ou une VM de reprise préparée par le formateur.

### 3. Pro : « Configurer pour le travail ou l'école »

Sur l'édition **Pro** connectée au réseau, l'OOBE propose **Configurer pour une utilisation professionnelle ou scolaire** : connexion avec un compte **Entra ID** (jonction Entra/Intune, voire Autopilot si le poste est enregistré, chapitre 16). Selon les builds, un lien **Options de connexion → Joindre un domaine à la place** crée un compte local en vue d'une jonction AD ultérieure : à vérifier sur l'ISO utilisée.

### 4. Rufus (poste physique, cas ponctuel)

**Rufus** génère une clé USB dont l'image contient déjà un fichier de réponse (compte local, pas d'Internet requis, contrôle TPM désactivable). C'est en réalité la méthode n° 1, automatisée par un outil tiers.

> [!WARNING] Ne pas désactiver les contrôles TPM/Secure Boot en entreprise
> Rufus et certaines clés de registre (`LabConfig\BypassTPMCheck`) permettent d'installer Windows 11 sur du matériel non compatible. Le poste fonctionne mais n'est **pas supporté** : Microsoft peut lui refuser des mises à jour, et il n'a pas le socle de sécurité (TPM pour BitLocker, VBS) que Windows 11 suppose.

---

## Configuration post-OOBE

Une fois le bureau atteint, quelques réglages immédiats :

### Vie privée

Lors de l'OOBE, désactiver **toutes les options de télémétrie** (localisation, données de diagnostic, publicité, expériences personnalisées, etc.).

### Questions de sécurité

Windows demande 3 questions de sécurité pour le compte local. En lab, on peut mettre des réponses simples (on ne s'en servira probablement pas).

### Vérifier l'installation

```powershell
# Nom du PC
hostname

# Édition et version de Windows
Get-ComputerInfo | Select-Object OsName, OsVersion, OsBuildNumber

# Architecture
[Environment]::Is64BitOperatingSystem

# Espace disque disponible
Get-PSDrive C | Select-Object Used, Free, @{N="TotalGo";E={[math]::Round(($_.Used+$_.Free)/1GB,1)}}
```

---

## Mise à niveau d'un poste existant

### Vérifier la compatibilité

| Outil | Usage |
|-------|-------|
| **Contrôle d'intégrité du PC** (*PC Health Check*) | Un poste, interface graphique |
| `Get-Tpm`, `Confirm-SecureBootUEFI` | Script, à grande échelle |
| Rapport de compatibilité d'Intune / Autopatch | Parc géré dans le cloud |

```powershell
Get-Tpm | Select-Object TpmPresent, TpmReady, ManufacturerVersion
Confirm-SecureBootUEFI                      # True = Secure Boot actif
(Get-CimInstance Win32_Processor).Name      # comparer à la liste des processeurs supportés
```

### Les trois chemins

| Depuis | Méthode | Durée |
|--------|---------|-------|
| Windows 11 24H2/25H2 → 26H2 | Windows Update — **package d'activation** | 1 redémarrage |
| Windows 11 23H2 ou antérieur | Windows Update ou ISO — mise à niveau complète | 30 à 90 min |
| **Windows 10** 22H2 | Assistant d'installation, ISO (`setup.exe`), ou Windows Update si éligible | 30 à 90 min |

La **mise à niveau en place** conserve les applications, les paramètres et les fichiers. Elle se lance depuis l'ISO montée :

```cmd
:: Interactive
D:\setup.exe

:: Sans intervention, avec contrôle préalable de compatibilité uniquement
D:\setup.exe /auto upgrade /compat scanonly /quiet
:: Code de sortie 0xC1900210 = aucun problème de compatibilité

:: Mise à niveau silencieuse réelle, sans télémétrie dynamique
D:\setup.exe /auto upgrade /quiet /eula accept /dynamicupdate disable
```

> [!TIP] Retour arrière
> Pendant **10 jours** après une mise à niveau, *Paramètres → Système → Récupération → Revenir en arrière* restaure la version précédente (dossier `C:\Windows.old`). Le délai se règle avec `DISM /Online /Set-OSUninstallWindow /Value:30`.

### Installation propre ou mise à niveau ?

| | Mise à niveau en place | Installation propre (ou image, chap. 16) |
|-|------------------------|------------------------------------------|
| Applications et données | Conservées | Perdues → migration (USMT, OneDrive, chap. 16) |
| Durée de l'intervention | Courte | Plus longue (réinstaller les applications) |
| « Hygiène » du poste | Hérite des problèmes du système précédent | Poste propre, standardisé |
| En entreprise | Parc homogène et sain | Changement de matériel, poste instable |

---

## Récapitulatif

> [!summary] L'essentiel du chapitre
> - **Prérequis matériels** : TPM 2.0, Secure Boot, UEFI, 4 Go RAM, 64 Go, 2 cœurs
> - **Édition entreprise** : Pro minimum (Hyper-V, BitLocker, GPO, domaine, App Control)
> - **Comptes** : local (SAM) · Microsoft · professionnel (Entra ID) · domaine (AD)
>   - `dsregcmd /status` pour voir la jonction
> - **Compte local à l'OOBE** : fichier de réponse (pérenne) · sans réseau : BLOQUÉ en 26H2
>   - BYPASSNRO → "Je n'ai pas Internet" (marche sur 26300.9457, fragile)
>   - **BYPASSNRO** : selon la build, ms-cxh:localonly : bloqué → jamais en procédure
> - **Mise à niveau** : 24H2/25H2 → 26H2 : package d'activation (1 redémarrage)
>   - Windows 10 → `setup.exe /auto upgrade` (fin de support W10 : 14/10/2025)
>   - 10 jours pour revenir en arrière (Windows.old)
> - **Vérification** : `winver`, `Get-ComputerInfo`, `Get-Tpm`, `Confirm-SecureBootUEFI`
