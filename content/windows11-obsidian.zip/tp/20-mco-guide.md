# TP 21. TP final : maintien en condition opérationnelle, version guidée

**Ta mission.** Depuis `PC01`, inventorie `PC01` et `PC02`, traite les écarts puis inscris les contrôles dans un plan de MCO. Utilise les scripts remis par le formateur et les postes du domaine.

[Revoir le cours](../cours/20-mco.md) · [Ouvrir le TP d’origine et les exercices complémentaires](20-mco.md)

## Établir le point de départ

### A1 — Produire le CSV des deux postes

Sur `PC01`, dans la session d’administration du domaine, ouvre PowerShell et lance `C:\MCO\Get-Inventaire.ps1 -ComputerName PC01,PC02 -Csv C:\MCO\inventaire.csv`. Ouvre le CSV et vérifie que les deux postes sont présents.

### A2 — Transformer les mesures en actions

Compare les lignes du CSV aux seuils du chapitre pour la version, les mises à jour, Defender, BitLocker, l’espace disque et le dernier redémarrage. Dans une fiche, note **poste**, **écart**, **priorité** et **action**.

## Corriger et mesurer de nouveau

### B1 — Actualiser Defender

Sur chacun des deux postes, dans PowerShell administrateur, lance `Update-MpSignature`. Relève ensuite `AntivirusSignatureVersion` et `AntivirusSignatureAge` avec `Get-MpComputerStatus`.

### B2 — Sauvegarder la récupération avant de chiffrer PC02 (bonus)

Si tu as passé le chapitre 09 ou l’atelier BitLocker du TP GPO, relève l’état de protection de `PC02` dans le CSV, note l’écart éventuel dans le plan de MCO et passe à B3.

Sinon, sur `PC02`, applique la stratégie BitLocker de l’atelier du TP GPO. Dans PowerShell administrateur, lance `Get-BitLockerVolume -MountPoint C:`. Si aucun protecteur de récupération n’existe, ajoute-le avec `Add-BitLockerKeyProtector -MountPoint C: -RecoveryPasswordProtector | Out-Null`. Lance le bloc suivant.

```powershell
$recovery = (Get-BitLockerVolume -MountPoint C:).KeyProtector |

    Where-Object KeyProtectorType -eq RecoveryPassword | Select-Object -First 1

Backup-BitLockerKeyProtector -MountPoint C: -KeyProtectorId $recovery.KeyProtectorId
```


Sur `SRV01`, vérifie l’enregistrement sous `PC02` avec le contrôle F2 du TP GPO en ciblant `PC02`. Une fois l’enregistrement confirmé, active BitLocker avec le TPM depuis le Panneau de configuration de `PC02` si le volume n’est pas encore protégé.

### B3 — Vérifier Windows Update et relancer un inventaire

Sur `PC02`, relève la dernière KB qualité dans **Windows Update → Historique**, le report appliqué et l’éventuel redémarrage en attente. Lance une recherche. Sur `PC01`, relance l’inventaire en choisissant un deuxième fichier CSV.

## Automatiser un contrôle et préparer la maintenance

### C1 — Planifier le contrôle quotidien

Sur `PC02`, place le script validé `C:\MCO\Test-Poste.ps1` et crée `C:\MCO\Logs`. Dans `taskschd.msc`, crée la tâche **Contrôle-Poste** sous **Fournil**, tous les jours à 8 h 30, sous `SYSTEM`. Utilise `powershell.exe` et les arguments ci-dessous. Vérifie que seuls les administrateurs et SYSTEM peuvent modifier le script.

```text
-NoProfile -ExecutionPolicy RemoteSigned -Command "& 'C:\MCO\Test-Poste.ps1' *> ('C:\MCO\Logs\{0:yyyyMMdd}.log' -f (Get-Date))"
```

### C2 — Valider l’exécution manuelle

Depuis le Planificateur sur `PC02`, exécute la tâche et actualise l’affichage. Lis son dernier résultat, puis ouvre le journal du jour dans `C:\MCO\Logs`.

### C3 — Rédiger le plan de MCO

Sur `PC01`, crée `C:\MCO\Plan-MCO.md`. Pour chaque contrôle, indique **responsable**, **fréquence**, **preuve attendue** et **action en cas d’échec**. Ajoute le prochain test de restauration, la durée de support des versions constatées et la référence à l’inventaire.

[Ouvrir le corrigé guidé](20-mco-guide-corrigev2.md)


[Afficher les corrections](20-mco-guide-corrigev2.md)
