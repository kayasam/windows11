# 12. Administrer SRV01 depuis PC01

> [!abstract] Deux machines, deux rôles
> **PC01** ouvre les connexions et **SRV01** les reçoit. Dans le TP, tu utilises **WinRM** pour vérifier DNS et DHCP sur le serveur. Les autres protocoles montrent comment la méthode change quand tu dois ouvrir un bureau, consulter les journaux ou accéder à un partage.

> [!note] État du lab après le TP 11
> `PC01` est joint à `ad.fournil.lab`. `SRV01` est démarré et les deux VM sont sur `vSwitch-Rennes`.

> [!tip] Identifiants du lab
> Dans la fenêtre d’identification de Windows, saisis `Administrateur@ad.fournil.lab` et le mot de passe fourni par le formateur.


| Je veux… | J’utilise… | Port TCP à repérer |
| --- | --- | --- |
| Vérifier des services en PowerShell | WinRM | 5985 dans le lab, 5986 en HTTPS |
| Ouvrir le bureau du serveur | RDP | 3389 |
| Ouvrir un terminal | SSH | 22 |
| Lire les événements du serveur | Observateur d’événements sur RPC | 135 pour trouver le service, puis ports négociés |
| Ouvrir un dossier partagé | SMB | 445 |
| Gérer une zone DNS avec une console | RSAT sur `PC01` | Selon la console. Pour cette démo DNS, commence par RPC, port 135 |
| Aider une personne sur sa session (repère) | Assistance rapide | HTTPS sortant, 443 |

## Le même réflexe à chaque fois

**Sur la machine qui reçoit la connexion**, regarde les ports TCP en écoute. Fais-le sur les deux VM pour comparer.

```powershell
hostname
Get-NetTCPConnection -State Listen |
    Sort-Object LocalPort |
    Select-Object LocalAddress, LocalPort, State
```

Une ligne `Listen` indique qu’un service attend des connexions sur cette adresse et ce port. **Depuis la machine qui appelle**, `Test-NetConnection -Port` indique si la connexion TCP atteint la cible. Le test TCP et l’ouverture de session répondent à deux questions différentes : « Puis-je atteindre le service ? » et « Mon compte a-t-il le droit d’y entrer ? ».

> [!example] Relevé du lab depuis l’hôte
> Le 20 novembre 2026, le test TCP a réussi vers `SRV01` sur **22, 135, 445 et 5985**, et vers `PC01` sur **135** parmi les mêmes ports testés. Le **3389** n’a répondu sur aucune des deux VM. Ce relevé mesure la joignabilité depuis l’hôte. Pour constater `Listen`, exécute la commande directement dans la VM.

## 1. WinRM · Vérifier DNS et DHCP

WinRM permet d’exécuter des commandes PowerShell sur un poste ou un serveur Windows à distance. Ici, tu vérifies l’état de DNS et DHCP depuis PC01.

Sur **SRV01**, en Windows PowerShell :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 5985 -ErrorAction SilentlyContinue
```

Sur **PC01**, ouvre Windows PowerShell. `Test-WSMan` doit afficher une réponse contenant `ProductVendor`. La commande suivante ouvre la fenêtre d’identification.

```powershell
Test-WSMan srv01.ad.fournil.lab
Enter-PSSession -ComputerName srv01.ad.fournil.lab -Credential 'Administrateur@ad.fournil.lab'
```

L’invite affiche le nom de **SRV01** entre crochets. Exécute `hostname` et `Get-Service DNS, DHCPServer`, relève les états, puis tape `Exit-PSSession`. Relance `hostname` pour vérifier ton retour sur **PC01**.

![Extrait de la capture du lab. La session est ouverte sur SRV01. Les services DNS et DHCP affichent Running. La capture utilise la forme courte FOURNIL\Administrateur pour le même compte.](../assets/captures/w11-16-winrm-session-reussie.png)

## 2. RDP · Ouvrir le bureau du serveur

RDP ouvre une session graphique sur un autre ordinateur. Tu peux y utiliser les menus et les consoles de SRV01 comme devant son écran.

Sur **SRV01**, dans **Gestionnaire de serveur → Serveur local → Bureau à distance**, clique sur l’état affiché. Si le formateur a prévu la démo, sélectionne **Autoriser les connexions à distance à cet ordinateur** et laisse l’authentification au niveau du réseau activée. Contrôle l’écoute sur **SRV01** :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 3389 -ErrorAction SilentlyContinue
```

Sur **PC01**, tape `Test-NetConnection srv01.ad.fournil.lab -Port 3389`. Si `TcpTestSucceeded` vaut `True`, ouvre `mstsc`, saisis `srv01.ad.fournil.lab` et connecte-toi avec le compte de l’encadré. Dans le bureau distant, `hostname` doit afficher `SRV01`. Déconnecte-toi après la démo.

## 3. SSH · Ouvrir un terminal

SSH ouvre un terminal distant chiffré. Il sert à administrer une machine en ligne de commande, sous Linux comme sous Windows avec OpenSSH.

Sur **SRV01**, vérifie que le serveur OpenSSH écoute :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 22 -ErrorAction SilentlyContinue
```

Sur **PC01**, teste `Test-NetConnection srv01.ad.fournil.lab -Port 22`. Pour SSH, la commande utilise la forme courte `FOURNIL\Administrateur` du même compte.

```powershell
ssh -l 'FOURNIL\Administrateur' srv01.ad.fournil.lab
```

À la première connexion, compare l’empreinte avec celle que fournit le formateur. Si SSH dit que la clé a changé, arrête-toi et fais confirmer l’identité du serveur. Dans le terminal distant, teste `hostname` puis tape `exit`.

![Capture du lab. La session SSH est ouverte et hostname renvoie SRV01.](../assets/captures/w11-12-ssh-srv01.png)

## 4. RPC · Consulter les événements à distance

RPC permet à une application d’appeler un service sur une autre machine. Ici, l’Observateur d’événements de PC01 demande les journaux à SRV01.

Sur **SRV01**, vérifie le port d’entrée RPC :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 135 -ErrorAction SilentlyContinue
```

Sur **PC01**, teste `Test-NetConnection srv01.ad.fournil.lab -Port 135`. Ouvre `eventvwr.msc`, fais un clic droit sur **Observateur d’événements (local) → Se connecter à un autre ordinateur**, puis saisis `srv01.ad.fournil.lab`. Ouvre **Journaux Windows → Système**. Le port 135 permet de repérer le service RPC. Si ce premier test réussit et que la console échoue, fais vérifier les droits et les règles de pare-feu de gestion distante des journaux, ainsi que les ports RPC négociés.

## 5. SMB · Accéder au dossier Commun

SMB permet d’ouvrir et de modifier des fichiers sur un partage réseau selon les droits du compte. Ici, tu accèdes au dossier Commun hébergé sur SRV01.

Sur **SRV01**, vérifie l’écoute SMB :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 445 -ErrorAction SilentlyContinue
```

Sur **PC01**, teste `Test-NetConnection srv01.ad.fournil.lab -Port 445`, puis ouvre `\\SRV01\Commun` dans l’Explorateur. Le dossier doit s’ouvrir si le partage du TP GPO existe et si le compte a les droits du partage et du dossier.

## 6. RSAT · Administrer DNS depuis PC01

RSAT fournit les consoles d’administration de Windows Server sur PC01. Tu peux par exemple consulter DNS, DHCP ou Active Directory dans une interface graphique.

Chaque console s’appuie sur ses propres services. Pour la démo, installe seulement **RSAT : outils du serveur DNS** via **Paramètres → Fonctionnalités facultatives**. Si cette entrée est difficile à trouver, recherche **Fonctionnalités facultatives** depuis Démarrer. En Windows PowerShell administrateur sur **PC01**, tu peux aussi exécuter :

```powershell
Add-WindowsCapability -Online -Name Rsat.Dns.Tools~~~~0.0.1.0
```

Sur **SRV01**, contrôle le premier port utilisé pour joindre la gestion DNS à distance :

```powershell
Get-NetTCPConnection -State Listen -LocalPort 135 -ErrorAction SilentlyContinue
```

Sur **PC01**, lance `dnsmgmt.msc`, connecte la console DNS à `SRV01` et ouvre **Zones de recherche directe → ad.fournil.lab**. Vérifie que les enregistrements s’affichent. Le port TCP/UDP 53 sert aux **requêtes DNS**, tandis que la console s’appuie sur la gestion distante.

![Capture du lab. Dans les fonctionnalités facultatives, recherche RSAT et installe uniquement la console nécessaire.](../assets/captures/w11-11-acces-distant-1.png)

> [!note] Assistance rapide et Bureau à distance
> L’Assistance rapide permet de **partager une session existante** avec l’accord de la personne aidée. Avec **RDP**, le technicien ouvre une session sur la machine distante. L’Assistance rapide utilise une connexion HTTPS sortante vers Microsoft. Le TP vérifie WinRM de PC01 vers SRV01.

[Faire le TP guidé](../tp/12-acces-distant-guide.md)

[Microsoft Learn · Get-NetTCPConnection](https://learn.microsoft.com/powershell/module/nettcpip/get-nettcpconnection?view=windowsserver2025-ps) · [Ports des services Windows](https://learn.microsoft.com/en-us/troubleshoot/windows-server/networking/service-overview-and-network-port-requirements) · [RSAT](https://learn.microsoft.com/windows-server/remote/remote-server-administration-tools) · [Assistance rapide](https://learn.microsoft.com/windows/client-management/client-tools/quick-assist)
