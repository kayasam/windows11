# TP 12. Administrer à distance : RSAT, WinRM, RPC et SSH, corrigé guidé

**Mission** · Configurer quatre façons d'administrer à distance : les consoles du serveur sur PC01 (RSAT), PowerShell à distance (WinRM), les consoles graphiques à distance (RPC) et SSH avec une clé.

**Avant de commencer** · `SRV01` et `PC01` démarrés, `PC01` joint au domaine. Sur **les deux** VM, ouvre une session `FOURNIL\Administrateur`.

[Revoir le cours](../cours/12-acces-distant.md) · [Correction détaillée](12-acces-distant-corrigev2.md)

---

## A — RSAT

### A1. Lancer l'installation sur PC01

Paramètres → Système → Fonctionnalités facultatives → **Afficher les fonctionnalités** → rechercher `RSAT` → cocher AD DS, DNS, DHCP → **Suivant** → **Ajouter**.

> [!success]- Afficher la correction — A1
> L'installation se fait depuis Windows Update (≈ 10 minutes, Internet obligatoire).
>
> ![w11-11-acces-distant-1](../assets/captures/w11-11-acces-distant-1.png)
>
> Équivalent PowerShell (administrateur) : `Add-WindowsCapability -Online -Name Rsat.Dns.Tools~~~~0.0.1.0` (et `Rsat.ActiveDirectory.DS-LDS.Tools`, `Rsat.DHCP.Tools`).

### A2. Utiliser les consoles

> [!success]- Afficher la correction — A2
> - `dsa.msc` : `stagiaire` est dans **Fournil → Utilisateurs**.
> - `dnsmgmt.msc` : dans `ad.fournil.lab`, la ligne `PC01` est un enregistrement **Hôte (A)** avec l'adresse de `PC01`.
> - `dhcpmgmt.msc` : la plage du TP 10 (`192.168.3.100` à `192.168.3.200` dans le lab).
>
> On administre le serveur **sans ouvrir de session dessus**. Les consoles utilisent le compte de la session de `PC01`.

---

## B — WinRM

### B1. Constater

> [!success]- Afficher la correction — B1
> - `Test-WSMan srv01` (sur PC01) : réponse normale, `ProductVendor : Microsoft Corporation`.
> - `Test-WSMan PC01` (sur SRV01) : **erreur rouge**.
> - Le service **Windows Remote Management (Gestion WSM)** de PC01 est **arrêté**, en démarrage **Manuel**.
>
> ![w11-12-services-winrm-arrete](../assets/captures/w11-12-services-winrm-arrete.png)
>
> Windows Server : WinRM actif d'office. Windows 11 : non.

### B2. Activer sur PC01

> [!success]- Afficher la correction — B2
> ![w11-12-enable-psremoting](../assets/captures/w11-12-enable-psremoting.png)
>
> Service démarré et automatique, écouteur sur le port **5985**, pare-feu ouvert. `Test-WSMan PC01` répond maintenant depuis SRV01.

### B3. Utiliser depuis SRV01

> [!success]- Afficher la correction — B3
> `Invoke-Command` affiche `PC01` puis le service *Spooler* en **Running**. **Aucun mot de passe** : Kerberos (domaine) + `Administrateur` est administrateur de `PC01`.
> Pendant `Enter-PSSession`, l'invite commence par **`[PC01]:`**. `Exit-PSSession` ramène sur SRV01.

---

## C — RPC

### C1. Constater l'échec

> [!success]- Afficher la correction — C1
> La connexion échoue : en général, **« le serveur RPC n'est pas disponible »**. Les consoles graphiques utilisent **RPC** (port 135 + un port choisi à la connexion), pas WinRM : activer WinRM ne suffit pas, et le pare-feu de Windows 11 bloque RPC par défaut.

### C2. Ouvrir le pare-feu de PC01

> [!success]- Afficher la correction — C2
> Les 12 règles passent en vert (icône cochée). Équivalent PowerShell, sur PC01 en administrateur :
> ```powershell
> Enable-NetFirewallRule -DisplayGroup "Gestion à distance des journaux des événements", "Gestion des services à distance"
> ```
> Sur tout un parc, on fait la même chose par **GPO** (règles prédéfinies du pare-feu).

### C3. Réessayer depuis SRV01

> [!success]- Afficher la correction — C3
> - L'arborescence affiche **Observateur d'événements (PC01)** : on lit le journal Système de PC01 depuis le serveur.
> - Dans **Gestion de l'ordinateur (PC01)**, le Spouleur s'arrête puis redémarre ; `Get-Service Spooler` sur PC01 affiche **Running**.

---

## D — SSH avec une clé

### D1. Première connexion

> [!success]- Afficher la correction — D1
> SSH demande de faire confiance à l'**empreinte** du serveur (première connexion seulement) → `yes`. Puis mot de passe. `hostname` → `SRV01`.
>
> ![w11-12-ssh-srv01](../assets/captures/w11-12-ssh-srv01.png)

### D2. Créer la paire de clés

> [!success]- Afficher la correction — D2
> Dans `C:\Users\<ton profil>\.ssh\` :
> - `id_ed25519` = clé **privée**, reste sur PC01, **ne se partage jamais** ;
> - `id_ed25519.pub` = clé **publique**, se copie sur les serveurs.
>
> (Et `known_hosts`, créé en D1 : l'empreinte de SRV01.)

### D3. Copier la clé publique sur SRV01

> [!success]- Afficher la correction — D3
> La clé est ajoutée à `C:\ProgramData\ssh\administrators_authorized_keys` : pour un **administrateur**, OpenSSH pour Windows lit ce fichier-là, pas `.ssh\authorized_keys`. `icacls` ne laisse les droits qu'aux *Administrateurs* et à *SYSTEM* : sinon, SSH ignore le fichier par sécurité. `icacls` affiche *1 fichiers correctement traités*.

### D4. Se reconnecter

> [!success]- Afficher la correction — D4
> **Plus de mot de passe demandé** : la clé privée de PC01 prouve ton identité.
> Si le mot de passe est encore demandé : sur SRV01, vérifie le contenu (`Get-Content C:\ProgramData\ssh\administrators_authorized_keys`, une ligne qui commence par `ssh-ed25519`) et les droits (`icacls`) du fichier.

[Retour à l'énoncé guidé](12-acces-distant-guide.md)
